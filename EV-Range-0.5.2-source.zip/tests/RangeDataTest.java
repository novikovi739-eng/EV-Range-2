import ru.ivan.evrangetest.RangeData;
import org.json.*;
public class RangeDataTest {
 static JSONObject row(int id,double km,Object a,Object b,long start,long end)throws Exception{return new JSONObject().put("id",id).put("odometer_mileage",km).put("soc_start",a).put("soc_end",b).put("ride_start",start).put("ride_finish",end);}
 static void near(double a,double b){if(Math.abs(a-b)>1e-8||!Double.isFinite(a))throw new AssertionError(a+" != "+b);}
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  JSONArray rows=new JSONArray().put(row(1,2,84,83,1001,1100)).put(row(2,8,83,81,1101,1200));
  RangeData.Stats s=RangeData.calculate(new JSONObject().put("result",rows),53,1000,2000);
  near(s.average(),15.9);near(s.kwh,1.59);near(s.range(53,82,50),106.66666666666667);near(s.range(53,82,20),206.66666666666666);near(s.range(53,82,5),256.6666666666667);near(s.range(53,15,50),0);near(s.range(53,82,10),240);near(s.range(53,8,10),0);ok(Double.isNaN(s.range(53,101,10)));
  rows.put(row(1,2,84,83,1001,1100)).put(row(3,5,JSONObject.NULL,81,1201,1300)).put(row(4,3,81,81,1301,1400)).put(row(5,3,81,82,1401,1500)).put(row(6,0,81,80,1501,1600)).put(row(7,1,81,80,900,1100)).put(row(8,1,81,80,1900,2100));
  s=RangeData.calculate(new JSONObject().put("result",rows),53,1000,2000);
  near(s.average(),15.9);ok(s.used==2&&s.duplicates==1&&s.missing==1&&s.noDrop==2&&s.invalid==1&&s.outside==2);
  ok(Double.isNaN(RangeData.calculate(new JSONObject().put("result",new JSONArray()),53,1000,2000).average()));
  ok(RangeData.calculate(new JSONObject().put("result",rows).put("has_more",true),53,1000,2000).partial);
  ok(!RangeData.fresh(Double.NaN,2000)&&!RangeData.fresh(1000,2000)&&RangeData.fresh(1900,2000)&&!RangeData.fresh(2400,2000));
  ok(Double.isNaN(RangeData.number(new JSONObject().put("x",JSONObject.NULL),"x")));ok(Double.isNaN(RangeData.number(new JSONObject().put("x",false),"x")));
  near(RangeData.number(new JSONObject().put("x","11.98"),"x"),11.98);
  boolean thrown=false;try{RangeData.calculate(new JSONObject(),53,1000,2000);}catch(JSONException e){thrown=true;}ok(thrown);
  System.out.println("PASS: weighted consumption, reserve, invalid SOC, exclusions, duplicate IDs, period boundaries, empty/malformed results, partial history, freshness and null parsing.");
 }
}
