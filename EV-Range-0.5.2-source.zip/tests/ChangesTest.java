package ru.ivan.evrangetest;
import org.json.*;
public class ChangesTest{
 public static void main(String[] args)throws Exception{
 JSONObject a=Changes.snapshot(new JSONObject("{\"ignition\":false,\"locked\":true,\"battery\":82,\"board_network_voltage\":12.22,\"speed\":0}"));
 if(!Changes.compare(a,a).isEmpty())throw new AssertionError("duplicate");
 JSONObject b=Changes.snapshot(new JSONObject("{\"ignition\":true,\"locked\":false,\"battery\":81,\"board_network_voltage\":12.21,\"speed\":8}"));String d=Changes.compare(a,b);
 if(!d.contains("движение")||!d.contains("открыт")||!d.contains("82 → 81")||d.contains("АКБ"))throw new AssertionError(d);
 if(!Changes.compare(a,new JSONObject()).isEmpty())throw new AssertionError("missing became change");
 JSONObject gps=Changes.snapshot(new JSONObject("{\"ignition\":false,\"speed\":20}"));if(gps.optBoolean("moving"))throw new AssertionError("GPS spike");
 JSONObject cold=Changes.snapshot(new JSONObject().put("temp_from_remote_control",2)); JSONObject warm=Changes.snapshot(new JSONObject().put("temp_from_remote_control",23).put("heater_desired_temp",29).put("heater_fluid_temp",74));if(!Changes.compare(cold,warm).contains("Салон, °C: 2 → 23"))throw new AssertionError("cabin mapping");
 System.out.println("ChangesTest OK");
 }
}
