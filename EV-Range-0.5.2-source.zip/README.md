# EV Range 0.4

Android-клиент для личного использования: чтение данных ТехноТрека и оценка запаса хода. Пакет ru.ivan.evrange. Устанавливается РЯДОМ с 0.3 (ru.ivan.evrangetest), так как прежний ключ подписи не сохранился. Требуется отдельный вход по SMS, старое приложение удалять не нужно.

## Интерфейс
Белая стилизованная полигональная 3D-модель седана с чёрными стёклами, перспективой и вращением жестом. Это НЕ точная заводская модель Evolute и НЕ фотография. Жест на модели вращает её; горизонтальный свайп вне модели переключает страницы. Есть переключение страниц нажатием нижнего индикатора. На первой странице модель, заряд, температура воздуха с явным +/−, температура батареи, общий пробег и прогноз до 50%, 20%, 5%. Порог 10% удалён. Если заряд ниже порога, показано «уже ≤ …%». На второй странице недельный расход, исключения, отдельные поездки, погода и дополнительные показания. Стрелка ↑ закреплена снизу слева и открывает панель входа снизу.

## Анимация и достоверность
При свежей связи и включённом зажигании модель включает фары. Это пользовательская визуальная условность состояния машины, не точное отображение датчика фар. Колёса вращаются только если свежие показания одновременно содержат зажигание=true и скорость>0,5 км/ч; изменение GPS-координат не используется для этого вывода. При charging=true отображается кабель, поскольку идёт зарядка. При charging=false отдельного датчика подключения нет, поэтому написано «пистолет: нет данных»; отсутствие кабеля на иллюстрации не означает подтверждённое отключение. При устаревшей связи анимации выключены и состояние помечено неизвестным. Никаких команд автомобилю.

## Расчёт
Последние 168 часов. Энергия = указанная ёмкость × падение SOC / 100. Средний расход = сумма энергии / сумма километров × 100. Запас до R% = ёмкость × max(0, SOC−R) / средний расход. Это оценка по процентам и округлённым километрам, не измеренные кВт·ч; износ неизвестен. Нет выдуманной поправки на погоду. Исключаются отсутствующие/невалидные данные, неположительное расстояние, отсутствие падения SOC, повторы и поездки за пределами интервала. Нулевое падение SOC не доказывает GPS-сбой. При неполной истории или связи старше 15 минут прогноз не показывается. last_online — время связи, не время всех датчиков.

## Приватность
Только HTTPS и INTERNET. SMS-код и телефон — напрямую ТехноТреку. Токены AES-GCM в Android Keystore; резервное копирование отключено. Open-Meteo получает только координаты с округлением до 0,01°, без токена и VIN. Нет фонового опроса. Скриншоты разрешены. CAPTCHA пока не реализована; если требуется, вход останавливается.

## Проверки и сборка
Java-компиляция; JVM-тесты расчётов (включая 50/20/5%, низкий заряд, взвешивание, неполные данные, повторные записи и свежесть); проверка подписи APK. Интерфейс/жесты на физическом Android в среде сборки не проверены. Нативный Canvas рисует 3D-полигоны без внешнего движка.

Для сборки нужны Java 17 runtime, ECJ 3.38.0, Android platform 35, Build Tools 35.0.0. EV_SDK указывает каталог с ecj.jar, android-35/android.jar и android-15 инструментами Build Tools. Запустить python3 build.py. Для подписи нужны private-signing/release.p12 и private-signing/password.txt из отдельного приватного архива ключа. Ключ НИКОГДА не включается в APK или публичные исходники. Исходники с тестами включены в assets/source.zip APK.


## Version 0.5
Photo-based white i-Pro and launcher icon; no 360 rotation. Animated headlights (ignition/motion convention), rotating wheel overlays and charging cable. Explicit battery and cabin temperature labels. Only temp_from_remote_control is used for cabin; missing sensor remains unknown.
Optional JobScheduler monitoring every >=15 minutes, Android may delay. Enable via bottom-left arrow and notification permission. No vehicle commands. Polling compares fresh state only, not activity history; short events can be missed. Baseline on first check, deduplicated changes and one failure alert until recovery. Encrypted tokens shared with UI. Thresholds: 1% SOC, 1 degree, 1 km, 0.1 V. Not tested on a physical phone. Same signing key/package as 0.4; install as update.

0.5.1: cabin mapping verified against Technotrek APK: CarActivity RowItem in_salon_info and salon_toolbar both use Sensors.getTemp_from_remote_control(). Climate target and heater fluid are separate.
